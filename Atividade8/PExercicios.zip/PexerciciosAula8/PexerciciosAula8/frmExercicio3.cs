﻿namespace PexerciciosAula8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string auxiliar1, auxiliar2;

            if (String.IsNullOrEmpty(txtFrase.Text))
                MessageBox.Show("Por favor, digite uma frase!");         
            else 
            {
                if (txtFrase.Text.Length <= 50)
                {
                    auxiliar1 = txtFrase.Text.ToUpper().Replace(" ", "");
                    auxiliar2 = auxiliar1;
                    char[] auxVetor = auxiliar1.ToCharArray();

                    Array.Reverse(auxVetor);

                    auxiliar1 = "";

                    foreach (var element in auxVetor)
                          auxiliar1 += element;

                    if (auxiliar1 == auxiliar2)
                        txtResultado.Text = "A Palavra digitada é um Palíndromo!";
                    else
                        txtResultado.Text = "A Palavra digita não é um Palíndromo!";
                }
                else MessageBox.Show("A frase digitada é muito longa!");
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            txtFrase.Text = "";
            txtResultado.Text = "";
        }
    }
}
