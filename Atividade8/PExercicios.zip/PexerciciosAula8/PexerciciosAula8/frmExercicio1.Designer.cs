﻿namespace PexerciciosAula8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQntdEspacos = new System.Windows.Forms.Button();
            this.btnQntdR = new System.Windows.Forms.Button();
            this.btnQntdPares = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.rchTxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQntdEspacos
            // 
            this.btnQntdEspacos.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnQntdEspacos.Location = new System.Drawing.Point(12, 230);
            this.btnQntdEspacos.Name = "btnQntdEspacos";
            this.btnQntdEspacos.Size = new System.Drawing.Size(122, 82);
            this.btnQntdEspacos.TabIndex = 1;
            this.btnQntdEspacos.Text = "Quantidade de Espaços em Branco";
            this.btnQntdEspacos.UseVisualStyleBackColor = true;
            this.btnQntdEspacos.Click += new System.EventHandler(this.btnQntdEspacos_Click);
            // 
            // btnQntdR
            // 
            this.btnQntdR.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnQntdR.Location = new System.Drawing.Point(149, 230);
            this.btnQntdR.Name = "btnQntdR";
            this.btnQntdR.Size = new System.Drawing.Size(122, 82);
            this.btnQntdR.TabIndex = 2;
            this.btnQntdR.Text = "Quantidade de \'R\'";
            this.btnQntdR.UseVisualStyleBackColor = true;
            this.btnQntdR.Click += new System.EventHandler(this.btnQntdR_Click);
            // 
            // btnQntdPares
            // 
            this.btnQntdPares.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnQntdPares.Location = new System.Drawing.Point(288, 230);
            this.btnQntdPares.Name = "btnQntdPares";
            this.btnQntdPares.Size = new System.Drawing.Size(122, 82);
            this.btnQntdPares.TabIndex = 3;
            this.btnQntdPares.Text = "Quantidade de Pares";
            this.btnQntdPares.UseVisualStyleBackColor = true;
            this.btnQntdPares.Click += new System.EventHandler(this.btnQntdPares_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLimpar.Location = new System.Drawing.Point(433, 230);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(122, 82);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // rchTxtFrase
            // 
            this.rchTxtFrase.Location = new System.Drawing.Point(12, 12);
            this.rchTxtFrase.Name = "rchTxtFrase";
            this.rchTxtFrase.Size = new System.Drawing.Size(543, 206);
            this.rchTxtFrase.TabIndex = 5;
            this.rchTxtFrase.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 333);
            this.Controls.Add(this.rchTxtFrase);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnQntdPares);
            this.Controls.Add(this.btnQntdR);
            this.Controls.Add(this.btnQntdEspacos);
            this.Name = "frmExercicio1";
            this.Text = "Exercicio 1";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnQntdEspacos;
        private Button btnQntdR;
        private Button btnQntdPares;
        private Button btnLimpar;
        private RichTextBox rchTxtFrase;
    }
}