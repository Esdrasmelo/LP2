﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PexerciciosAula8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double numero;
            double resultado = 1;

            if (Double.TryParse(txtNumero.Text, out numero))
            {
                if (numero <= 0) MessageBox.Show("O Número digitado precisa ser maior do que Zero!");
                else 
                {
                    for (int contador = 2; contador <= numero; contador++) 
                        resultado += 1.0 / contador;

                    txtResultado.Text = resultado.ToString("N2");
                }
            }
            else MessageBox.Show("Valor Inválido!");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero.Text = "";
            txtResultado.Text = "";
        }
    }
}
