﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PexerciciosAula8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnQntdEspacos_Click(object sender, EventArgs e)
        {
            int qtdEspacos = 0;

            for (int i = 0; i < rchTxtFrase.Text.Length; i++)
                if (rchTxtFrase.Text[i] == ' ')  qtdEspacos += 1;

            MessageBox.Show("A Quantidade de Espaços em Branco é: " + qtdEspacos);
        }

        private void btnQntdR_Click(object sender, EventArgs e)
        {
            int contador, qtdDeLetraR = 0;

            contador = 0;
            while (contador < rchTxtFrase.Text.Length)
            {
                if (rchTxtFrase.Text[contador] == 'R' || rchTxtFrase.Text[contador] == 'r')
                    qtdDeLetraR+= 1;

                contador++;
            }

            MessageBox.Show("A Quantidade de 'R' é: " + qtdDeLetraR);
        }

        private void btnQntdPares_Click(object sender, EventArgs e)
        {
            int qtdPares = 0;

            for (int contador = 0; contador < rchTxtFrase.Text.Length; contador++)
            {
                if (contador > 0)
                {
                    if (rchTxtFrase.Text[contador] == rchTxtFrase.Text[contador - 1])
                    {
                        qtdPares += 1;
                        contador++; 
                    }
                }
            }

            MessageBox.Show("A Quantidade de Pares é : " + qtdPares);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchTxtFrase.Text = "";
        }
    }
}
