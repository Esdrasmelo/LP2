﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PexerciciosAula8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome;
            string cargo;
            string matricula;
            double producao;
            double salario;
            double gratificacao;
            double salarioBruto;
            int D, C, B;

            if (String.IsNullOrEmpty(txtNome.Text) || String.IsNullOrEmpty(txtCargo.Text) || String.IsNullOrEmpty(txtMatricula.Text)
                || String.IsNullOrEmpty(txtProducao.Text) || String.IsNullOrEmpty(txtSalario.Text) || String.IsNullOrEmpty(txtGratificacao.Text)) 
                MessageBox.Show("Por favor, informe todos os dados primeiro.");
            else 
            {
                if (Double.TryParse(txtProducao.Text, out producao) && Double.TryParse(txtSalario.Text, out salario) && Double.TryParse(txtGratificacao.Text, out gratificacao)) 
                {
                    nome = txtNome.Text;
                    cargo = txtCargo.Text;
                    matricula = txtMatricula.Text;

                    if (producao >= 150) 
                    {
                        D = 1;
                        C = 1;
                        B = 1;
                    }
                    else if (producao >= 120) 
                    {
                        D = 0;
                        C = 1;
                        B = 1;
                    }
                    else if (producao >= 100) 
                    {
                        D = 0;
                        C = 0;
                        B = 1;
                    }
                    else 
                    {
                        D = 0;
                        C = 0;
                        B = 0;
                    }

                    salarioBruto = salario + salario * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao; 

                    if (salarioBruto > 7000) 
                    {
                        if (producao >= 150 && gratificacao > 0) 
                        {
                            txtSalarioBruto.Text = salarioBruto.ToString("N2");

                            MessageBox.Show("Funcionário : " + nome + '\n' + 
                                            "Cargo: " + cargo + '\n' + 
                                            "Matrícula: " + matricula + '\n' +
                                            "Salário Bruto: " + salarioBruto.ToString("N2"));
                        }
                        else
                        {
                            txtSalarioBruto.Text = "7.000,00";

                            MessageBox.Show("Funcionário : " + nome + '\n' +
                                            "Cargo: " + cargo + '\n' +
                                            "Matrícula: " + matricula + '\n' +
                                            "Salário Bruto: 7.000,00" + "\n\n" + 
                                            "Produção inferior a 150! Ou Gratificação Menor do Zero!\n" +
                                            "O Salário Bruto não pode ser Maior do que 7.000,00!");
                        }
                    }
                    else if (salarioBruto > 0) 
                    {
                        txtSalarioBruto.Text = salarioBruto.ToString("N2");

                        MessageBox.Show("Funcionário : " + nome + '\n' +
                                           "Cargo: " + cargo + '\n' +
                                           "Matrícula: " + matricula + '\n' +
                                           "Salário Bruto: " + salarioBruto.ToString("N2"));
                    }
                    else { 
                        txtSalarioBruto.Text = salarioBruto.ToString("N2");

                        MessageBox.Show("Funcionário : " + nome + '\n' +
                                        "Cargo: " + cargo + '\n' +
                                        "Matrícula: " + matricula + '\n' +
                                        "Salário Bruto: " + salarioBruto.ToString("N2") + "\n\n" +
                                        "Salário Menor ou Igual a Zero!");
                    }
                }
                else
                    MessageBox.Show("Você informou um valor inválido! Por favor, digite novamente.");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtCargo.Text = "";
            txtMatricula.Text = "";
            txtProducao.Text = "";
            txtSalario.Text = "";
            txtGratificacao.Text = "";
            txtSalarioBruto.Text = "";
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {  
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
