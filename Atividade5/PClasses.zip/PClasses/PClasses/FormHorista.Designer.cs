﻿namespace PClasses
{
    partial class FormHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxNome = new System.Windows.Forms.TextBox();
            this.txtBoxSalarioPHora = new System.Windows.Forms.TextBox();
            this.txtBoxNumeroHoras = new System.Windows.Forms.TextBox();
            this.txtBoxMatricula = new System.Windows.Forms.TextBox();
            this.gpBoxHomeOffice = new System.Windows.Forms.GroupBox();
            this.rdBtnNao = new System.Windows.Forms.RadioButton();
            this.rdBtnSim = new System.Windows.Forms.RadioButton();
            this.lblNumeroHoras = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioPHora = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtBoxDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtBoxDiasFaltas = new System.Windows.Forms.TextBox();
            this.lblDiasFaltas = new System.Windows.Forms.Label();
            this.btnInstanciarHorista = new System.Windows.Forms.Button();
            this.gpBoxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBoxNome
            // 
            this.txtBoxNome.Location = new System.Drawing.Point(347, 84);
            this.txtBoxNome.Name = "txtBoxNome";
            this.txtBoxNome.Size = new System.Drawing.Size(139, 20);
            this.txtBoxNome.TabIndex = 19;
            // 
            // txtBoxSalarioPHora
            // 
            this.txtBoxSalarioPHora.Location = new System.Drawing.Point(347, 122);
            this.txtBoxSalarioPHora.Name = "txtBoxSalarioPHora";
            this.txtBoxSalarioPHora.Size = new System.Drawing.Size(139, 20);
            this.txtBoxSalarioPHora.TabIndex = 18;
            // 
            // txtBoxNumeroHoras
            // 
            this.txtBoxNumeroHoras.Location = new System.Drawing.Point(347, 161);
            this.txtBoxNumeroHoras.Name = "txtBoxNumeroHoras";
            this.txtBoxNumeroHoras.Size = new System.Drawing.Size(139, 20);
            this.txtBoxNumeroHoras.TabIndex = 17;
            // 
            // txtBoxMatricula
            // 
            this.txtBoxMatricula.Location = new System.Drawing.Point(347, 45);
            this.txtBoxMatricula.Name = "txtBoxMatricula";
            this.txtBoxMatricula.Size = new System.Drawing.Size(139, 20);
            this.txtBoxMatricula.TabIndex = 16;
            // 
            // gpBoxHomeOffice
            // 
            this.gpBoxHomeOffice.Controls.Add(this.rdBtnNao);
            this.gpBoxHomeOffice.Controls.Add(this.rdBtnSim);
            this.gpBoxHomeOffice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpBoxHomeOffice.Location = new System.Drawing.Point(55, 280);
            this.gpBoxHomeOffice.Name = "gpBoxHomeOffice";
            this.gpBoxHomeOffice.Size = new System.Drawing.Size(153, 75);
            this.gpBoxHomeOffice.TabIndex = 15;
            this.gpBoxHomeOffice.TabStop = false;
            this.gpBoxHomeOffice.Text = "Home Office";
            // 
            // rdBtnNao
            // 
            this.rdBtnNao.AutoSize = true;
            this.rdBtnNao.Location = new System.Drawing.Point(6, 42);
            this.rdBtnNao.Name = "rdBtnNao";
            this.rdBtnNao.Size = new System.Drawing.Size(56, 24);
            this.rdBtnNao.TabIndex = 7;
            this.rdBtnNao.TabStop = true;
            this.rdBtnNao.Text = "Não";
            this.rdBtnNao.UseVisualStyleBackColor = true;
            // 
            // rdBtnSim
            // 
            this.rdBtnSim.AutoSize = true;
            this.rdBtnSim.Location = new System.Drawing.Point(6, 19);
            this.rdBtnSim.Name = "rdBtnSim";
            this.rdBtnSim.Size = new System.Drawing.Size(54, 24);
            this.rdBtnSim.TabIndex = 6;
            this.rdBtnSim.TabStop = true;
            this.rdBtnSim.Text = "Sim";
            this.rdBtnSim.UseVisualStyleBackColor = true;
            // 
            // lblNumeroHoras
            // 
            this.lblNumeroHoras.AutoSize = true;
            this.lblNumeroHoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroHoras.Location = new System.Drawing.Point(51, 161);
            this.lblNumeroHoras.Name = "lblNumeroHoras";
            this.lblNumeroHoras.Size = new System.Drawing.Size(134, 20);
            this.lblNumeroHoras.TabIndex = 14;
            this.lblNumeroHoras.Text = "Número de Horas";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(51, 82);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 13;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioPHora
            // 
            this.lblSalarioPHora.AutoSize = true;
            this.lblSalarioPHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioPHora.Location = new System.Drawing.Point(51, 122);
            this.lblSalarioPHora.Name = "lblSalarioPHora";
            this.lblSalarioPHora.Size = new System.Drawing.Size(124, 20);
            this.lblSalarioPHora.TabIndex = 12;
            this.lblSalarioPHora.Text = "Salário por Hora";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(51, 45);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 11;
            this.lblMatricula.Text = "Matricula";
            // 
            // txtBoxDataEntradaEmpresa
            // 
            this.txtBoxDataEntradaEmpresa.Location = new System.Drawing.Point(347, 198);
            this.txtBoxDataEntradaEmpresa.Name = "txtBoxDataEntradaEmpresa";
            this.txtBoxDataEntradaEmpresa.Size = new System.Drawing.Size(139, 20);
            this.txtBoxDataEntradaEmpresa.TabIndex = 21;
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(51, 198);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(217, 20);
            this.lblDataEntradaEmpresa.TabIndex = 20;
            this.lblDataEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // txtBoxDiasFaltas
            // 
            this.txtBoxDiasFaltas.Location = new System.Drawing.Point(347, 241);
            this.txtBoxDiasFaltas.Name = "txtBoxDiasFaltas";
            this.txtBoxDiasFaltas.Size = new System.Drawing.Size(139, 20);
            this.txtBoxDiasFaltas.TabIndex = 23;
            // 
            // lblDiasFaltas
            // 
            this.lblDiasFaltas.AutoSize = true;
            this.lblDiasFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasFaltas.Location = new System.Drawing.Point(51, 241);
            this.lblDiasFaltas.Name = "lblDiasFaltas";
            this.lblDiasFaltas.Size = new System.Drawing.Size(111, 20);
            this.lblDiasFaltas.TabIndex = 22;
            this.lblDiasFaltas.Text = "Dias de Faltas";
            // 
            // btnInstanciarHorista
            // 
            this.btnInstanciarHorista.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstanciarHorista.Location = new System.Drawing.Point(55, 390);
            this.btnInstanciarHorista.Name = "btnInstanciarHorista";
            this.btnInstanciarHorista.Size = new System.Drawing.Size(213, 57);
            this.btnInstanciarHorista.TabIndex = 24;
            this.btnInstanciarHorista.Text = "Instanciar Horista";
            this.btnInstanciarHorista.UseVisualStyleBackColor = true;
            this.btnInstanciarHorista.Click += new System.EventHandler(this.btnInstanciarHorista_Click);
            // 
            // FormHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 479);
            this.Controls.Add(this.btnInstanciarHorista);
            this.Controls.Add(this.txtBoxDiasFaltas);
            this.Controls.Add(this.lblDiasFaltas);
            this.Controls.Add(this.txtBoxDataEntradaEmpresa);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.txtBoxNome);
            this.Controls.Add(this.txtBoxSalarioPHora);
            this.Controls.Add(this.txtBoxNumeroHoras);
            this.Controls.Add(this.txtBoxMatricula);
            this.Controls.Add(this.gpBoxHomeOffice);
            this.Controls.Add(this.lblNumeroHoras);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblSalarioPHora);
            this.Controls.Add(this.lblMatricula);
            this.Name = "FormHorista";
            this.Text = "FormaHorista";
            this.gpBoxHomeOffice.ResumeLayout(false);
            this.gpBoxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxNome;
        private System.Windows.Forms.TextBox txtBoxSalarioPHora;
        private System.Windows.Forms.TextBox txtBoxNumeroHoras;
        private System.Windows.Forms.TextBox txtBoxMatricula;
        private System.Windows.Forms.GroupBox gpBoxHomeOffice;
        private System.Windows.Forms.RadioButton rdBtnNao;
        private System.Windows.Forms.RadioButton rdBtnSim;
        private System.Windows.Forms.Label lblNumeroHoras;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioPHora;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtBoxDataEntradaEmpresa;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtBoxDiasFaltas;
        private System.Windows.Forms.Label lblDiasFaltas;
        private System.Windows.Forms.Button btnInstanciarHorista;

    }
}