﻿namespace PClasses
{
    partial class FormMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.gpBoxHomeOffice = new System.Windows.Forms.GroupBox();
            this.rdBtnNao = new System.Windows.Forms.RadioButton();
            this.rdBtnSim = new System.Windows.Forms.RadioButton();
            this.txtBoxMatricula = new System.Windows.Forms.TextBox();
            this.txtBoxSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtBoxDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtBoxNome = new System.Windows.Forms.TextBox();
            this.btnInstanciarMensalidade = new System.Windows.Forms.Button();
            this.btnInstMensalistaPassParam = new System.Windows.Forms.Button();
            this.gpBoxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(58, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matricula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Data de Entrada na Empresa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(58, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nome";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(58, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Salário Mensal";
            // 
            // gpBoxHomeOffice
            // 
            this.gpBoxHomeOffice.Controls.Add(this.rdBtnNao);
            this.gpBoxHomeOffice.Controls.Add(this.rdBtnSim);
            this.gpBoxHomeOffice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpBoxHomeOffice.Location = new System.Drawing.Point(62, 206);
            this.gpBoxHomeOffice.Name = "gpBoxHomeOffice";
            this.gpBoxHomeOffice.Size = new System.Drawing.Size(153, 75);
            this.gpBoxHomeOffice.TabIndex = 5;
            this.gpBoxHomeOffice.TabStop = false;
            this.gpBoxHomeOffice.Text = "Home Office";
            // 
            // rdBtnNao
            // 
            this.rdBtnNao.AutoSize = true;
            this.rdBtnNao.Location = new System.Drawing.Point(6, 42);
            this.rdBtnNao.Name = "rdBtnNao";
            this.rdBtnNao.Size = new System.Drawing.Size(56, 24);
            this.rdBtnNao.TabIndex = 7;
            this.rdBtnNao.TabStop = true;
            this.rdBtnNao.Text = "Não";
            this.rdBtnNao.UseVisualStyleBackColor = true;
            // 
            // rdBtnSim
            // 
            this.rdBtnSim.AutoSize = true;
            this.rdBtnSim.Location = new System.Drawing.Point(6, 19);
            this.rdBtnSim.Name = "rdBtnSim";
            this.rdBtnSim.Size = new System.Drawing.Size(54, 24);
            this.rdBtnSim.TabIndex = 6;
            this.rdBtnSim.TabStop = true;
            this.rdBtnSim.Text = "Sim";
            this.rdBtnSim.UseVisualStyleBackColor = true;
            // 
            // txtBoxMatricula
            // 
            this.txtBoxMatricula.Location = new System.Drawing.Point(354, 51);
            this.txtBoxMatricula.Name = "txtBoxMatricula";
            this.txtBoxMatricula.Size = new System.Drawing.Size(139, 20);
            this.txtBoxMatricula.TabIndex = 6;
            // 
            // txtBoxSalarioMensal
            // 
            this.txtBoxSalarioMensal.Location = new System.Drawing.Point(354, 167);
            this.txtBoxSalarioMensal.Name = "txtBoxSalarioMensal";
            this.txtBoxSalarioMensal.Size = new System.Drawing.Size(139, 20);
            this.txtBoxSalarioMensal.TabIndex = 8;
            // 
            // txtBoxDataEntradaEmpresa
            // 
            this.txtBoxDataEntradaEmpresa.Location = new System.Drawing.Point(354, 128);
            this.txtBoxDataEntradaEmpresa.Name = "txtBoxDataEntradaEmpresa";
            this.txtBoxDataEntradaEmpresa.Size = new System.Drawing.Size(139, 20);
            this.txtBoxDataEntradaEmpresa.TabIndex = 9;
            // 
            // txtBoxNome
            // 
            this.txtBoxNome.Location = new System.Drawing.Point(354, 90);
            this.txtBoxNome.Name = "txtBoxNome";
            this.txtBoxNome.Size = new System.Drawing.Size(139, 20);
            this.txtBoxNome.TabIndex = 10;
            // 
            // btnInstanciarMensalidade
            // 
            this.btnInstanciarMensalidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstanciarMensalidade.Location = new System.Drawing.Point(62, 309);
            this.btnInstanciarMensalidade.Name = "btnInstanciarMensalidade";
            this.btnInstanciarMensalidade.Size = new System.Drawing.Size(213, 57);
            this.btnInstanciarMensalidade.TabIndex = 11;
            this.btnInstanciarMensalidade.Text = "Instanciar Mensalista";
            this.btnInstanciarMensalidade.UseVisualStyleBackColor = true;
            this.btnInstanciarMensalidade.Click += new System.EventHandler(this.btnInstanciarMensalidade_Click);
            // 
            // btnInstMensalistaPassParam
            // 
            this.btnInstMensalistaPassParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstMensalistaPassParam.Location = new System.Drawing.Point(321, 309);
            this.btnInstMensalistaPassParam.Name = "btnInstMensalistaPassParam";
            this.btnInstMensalistaPassParam.Size = new System.Drawing.Size(213, 57);
            this.btnInstMensalistaPassParam.TabIndex = 12;
            this.btnInstMensalistaPassParam.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstMensalistaPassParam.UseVisualStyleBackColor = true;
            // 
            // FormMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 430);
            this.Controls.Add(this.btnInstMensalistaPassParam);
            this.Controls.Add(this.btnInstanciarMensalidade);
            this.Controls.Add(this.txtBoxNome);
            this.Controls.Add(this.txtBoxDataEntradaEmpresa);
            this.Controls.Add(this.txtBoxSalarioMensal);
            this.Controls.Add(this.txtBoxMatricula);
            this.Controls.Add(this.gpBoxHomeOffice);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "FormMensalista";
            this.Text = "FormMensalista";
            this.gpBoxHomeOffice.ResumeLayout(false);
            this.gpBoxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gpBoxHomeOffice;
        private System.Windows.Forms.RadioButton rdBtnNao;
        private System.Windows.Forms.RadioButton rdBtnSim;
        private System.Windows.Forms.TextBox txtBoxMatricula;
        private System.Windows.Forms.TextBox txtBoxSalarioMensal;
        private System.Windows.Forms.TextBox txtBoxDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtBoxNome;
        private System.Windows.Forms.Button btnInstanciarMensalidade;
        private System.Windows.Forms.Button btnInstMensalistaPassParam;
    }
}