﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    class Horista: Empregado
    {
        public double SalarioHora { get; set; }
        public double NumeroHoras { get; set; }
        public int DiasFaltas { get; set; }

        public override double SalarioBruto()
        {
            return this.SalarioHora * this.NumeroHoras;
        }

        public override int CalculaTempoTrabalhado()
        {
            TimeSpan span = DateTime.Today.Subtract(this.DataEntradaEmpresa);
            return span.Days - this.DiasFaltas;
        }
    }
}
