﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
   abstract class Empregado
    {
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private bool homeOffice;

        public int Matricula
        {
            get { return this.matricula; }
            set { this.matricula = value;  }
        }

        public string NomeEmpregado
        {
            get { return this.nomeEmpregado; }
            set { this.nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return this.dataEntradaEmpresa; }
            set { this.dataEntradaEmpresa = value;  }
        }   

        public bool HomeOffice
        {
            get { return this.homeOffice; }
            set { this.homeOffice = value; }
        }

        public string VerificaHomeOffice()
        {
            if (this.homeOffice) return "Empregado trabalha em modelo Home Office";
            return "Empregado não trabalha em modelo Home Office";

        }

        public virtual int CalculaTempoTrabalhado()
        {
            TimeSpan span = DateTime.Today.Subtract(this.DataEntradaEmpresa);
            return (span.Days);
        }

        public abstract double SalarioBruto();
    }
}
