﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class FormMensalista : Form
    {
        public FormMensalista()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnInstanciarMensalidade_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista();
            mensalista.Matricula = Convert.ToInt32(txtBoxMatricula.Text);
            mensalista.NomeEmpregado = txtBoxNome.Text;
            mensalista.DataEntradaEmpresa = Convert.ToDateTime(txtBoxDataEntradaEmpresa.Text);
            mensalista.SalarioMensal = Convert.ToDouble(txtBoxSalarioMensal.Text);
            if (rdBtnSim.Checked) mensalista.HomeOffice = true;
            else mensalista.HomeOffice = false;
            MessageBox.Show(String.Format("Matrícula: {0}\nNome: {1}\nData Entrada: {2}\nSalário Bruto: {3}\nTempo empresa: {4}\nHome Office: {5}", mensalista.Matricula, mensalista.NomeEmpregado, mensalista.DataEntradaEmpresa.ToShortDateString(), mensalista.SalarioBruto().ToString("N2"), mensalista.CalculaTempoTrabalhado(), mensalista.VerificaHomeOffice()));        }
    }
}
