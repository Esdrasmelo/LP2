﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class FormHorista : Form
    {
        public FormHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
            Horista horista = new Horista();
            horista.NomeEmpregado = txtBoxNome.Text;
            horista.Matricula = Convert.ToInt32(txtBoxMatricula.Text);
            horista.NumeroHoras = Convert.ToInt32(txtBoxNumeroHoras.Text);
            horista.DiasFaltas = Convert.ToInt32(txtBoxDiasFaltas.Text);
            horista.SalarioHora = Convert.ToDouble(txtBoxSalarioPHora.Text);
            horista.DataEntradaEmpresa = Convert.ToDateTime(txtBoxDataEntradaEmpresa.Text);
            if (rdBtnSim.Checked) horista.HomeOffice = true;
            else horista.HomeOffice = false;
            MessageBox.Show(String.Format("Matrícula: {0}\nNome: {1}\nSalário por Hora: {2}\nSalário Bruto: {3}\nNúmero de Horas trabalhadas: {4}\nData de Entrada na empresa: {5}\nDias de Faltas: {6}", horista.Matricula, horista.NomeEmpregado, horista.SalarioHora, horista.SalarioBruto(), horista.NumeroHoras.ToString("N2"), horista.DataEntradaEmpresa.ToShortDateString(), horista.DiasFaltas));
        }
        }
    }
