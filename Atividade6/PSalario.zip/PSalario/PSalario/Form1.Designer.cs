﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFuncionario = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumeroFilhos = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIRPF = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.txtBoxNomeFuncionario = new System.Windows.Forms.TextBox();
            this.txtBoxNumeroFilhos = new System.Windows.Forms.TextBox();
            this.txtBoxSalarioBruto = new System.Windows.Forms.TextBox();
            this.btnVerificarDesconto = new System.Windows.Forms.Button();
            this.gpBoxSexo = new System.Windows.Forms.GroupBox();
            this.rdButtonMasculino = new System.Windows.Forms.RadioButton();
            this.rdButtonFeminino = new System.Windows.Forms.RadioButton();
            this.gpBoxEstadoCivil = new System.Windows.Forms.GroupBox();
            this.rdButtonSolteiro = new System.Windows.Forms.RadioButton();
            this.rdButtonCasado = new System.Windows.Forms.RadioButton();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.mskTxtBoxAliquotaINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtBoxDescontoIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtBoxDescontoINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtBoxAliquotaIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtBoxSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtBoxSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.picBoxFatec = new System.Windows.Forms.PictureBox();
            this.gpBoxSexo.SuspendLayout();
            this.gpBoxEstadoCivil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFatec)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNomeFuncionario
            // 
            this.lblNomeFuncionario.AutoSize = true;
            this.lblNomeFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFuncionario.Location = new System.Drawing.Point(60, 148);
            this.lblNomeFuncionario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeFuncionario.Name = "lblNomeFuncionario";
            this.lblNomeFuncionario.Size = new System.Drawing.Size(137, 16);
            this.lblNomeFuncionario.TabIndex = 0;
            this.lblNomeFuncionario.Text = "Nome do Funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioBruto.Location = new System.Drawing.Point(60, 193);
            this.lblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(85, 16);
            this.lblSalarioBruto.TabIndex = 1;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblNumeroFilhos
            // 
            this.lblNumeroFilhos.AutoSize = true;
            this.lblNumeroFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroFilhos.Location = new System.Drawing.Point(60, 231);
            this.lblNumeroFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumeroFilhos.Name = "lblNumeroFilhos";
            this.lblNumeroFilhos.Size = new System.Drawing.Size(114, 16);
            this.lblNumeroFilhos.TabIndex = 2;
            this.lblNumeroFilhos.Text = "Número de Filhos";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaINSS.Location = new System.Drawing.Point(60, 354);
            this.lblAliquotaINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(91, 16);
            this.lblAliquotaINSS.TabIndex = 3;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIRPF
            // 
            this.lblAliquotaIRPF.AutoSize = true;
            this.lblAliquotaIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaIRPF.Location = new System.Drawing.Point(61, 400);
            this.lblAliquotaIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliquotaIRPF.Name = "lblAliquotaIRPF";
            this.lblAliquotaIRPF.Size = new System.Drawing.Size(90, 16);
            this.lblAliquotaIRPF.TabIndex = 4;
            this.lblAliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFamilia.Location = new System.Drawing.Point(60, 448);
            this.lblSalarioFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(98, 16);
            this.lblSalarioFamilia.TabIndex = 5;
            this.lblSalarioFamilia.Text = "Salário Família";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioLiquido.Location = new System.Drawing.Point(61, 491);
            this.lblSalarioLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(98, 16);
            this.lblSalarioLiquido.TabIndex = 6;
            this.lblSalarioLiquido.Text = "Salário Líquido";
            // 
            // txtBoxNomeFuncionario
            // 
            this.txtBoxNomeFuncionario.Location = new System.Drawing.Point(250, 142);
            this.txtBoxNomeFuncionario.Name = "txtBoxNomeFuncionario";
            this.txtBoxNomeFuncionario.Size = new System.Drawing.Size(100, 22);
            this.txtBoxNomeFuncionario.TabIndex = 7;
            // 
            // txtBoxNumeroFilhos
            // 
            this.txtBoxNumeroFilhos.Location = new System.Drawing.Point(250, 228);
            this.txtBoxNumeroFilhos.Name = "txtBoxNumeroFilhos";
            this.txtBoxNumeroFilhos.Size = new System.Drawing.Size(100, 22);
            this.txtBoxNumeroFilhos.TabIndex = 8;
            // 
            // txtBoxSalarioBruto
            // 
            this.txtBoxSalarioBruto.Location = new System.Drawing.Point(250, 187);
            this.txtBoxSalarioBruto.Name = "txtBoxSalarioBruto";
            this.txtBoxSalarioBruto.Size = new System.Drawing.Size(100, 22);
            this.txtBoxSalarioBruto.TabIndex = 13;
            // 
            // btnVerificarDesconto
            // 
            this.btnVerificarDesconto.Location = new System.Drawing.Point(250, 281);
            this.btnVerificarDesconto.Name = "btnVerificarDesconto";
            this.btnVerificarDesconto.Size = new System.Drawing.Size(151, 39);
            this.btnVerificarDesconto.TabIndex = 14;
            this.btnVerificarDesconto.Text = "Verificar Desconto";
            this.btnVerificarDesconto.UseVisualStyleBackColor = true;
            this.btnVerificarDesconto.Click += new System.EventHandler(this.btnVerificarDesconto_Click);
            // 
            // gpBoxSexo
            // 
            this.gpBoxSexo.Controls.Add(this.rdButtonMasculino);
            this.gpBoxSexo.Controls.Add(this.rdButtonFeminino);
            this.gpBoxSexo.Location = new System.Drawing.Point(714, 64);
            this.gpBoxSexo.Name = "gpBoxSexo";
            this.gpBoxSexo.Size = new System.Drawing.Size(200, 100);
            this.gpBoxSexo.TabIndex = 15;
            this.gpBoxSexo.TabStop = false;
            this.gpBoxSexo.Text = "Sexo";
            // 
            // rdButtonMasculino
            // 
            this.rdButtonMasculino.AutoSize = true;
            this.rdButtonMasculino.Location = new System.Drawing.Point(18, 59);
            this.rdButtonMasculino.Name = "rdButtonMasculino";
            this.rdButtonMasculino.Size = new System.Drawing.Size(87, 20);
            this.rdButtonMasculino.TabIndex = 17;
            this.rdButtonMasculino.TabStop = true;
            this.rdButtonMasculino.Text = "Masculino";
            this.rdButtonMasculino.UseVisualStyleBackColor = true;
            // 
            // rdButtonFeminino
            // 
            this.rdButtonFeminino.AutoSize = true;
            this.rdButtonFeminino.Location = new System.Drawing.Point(18, 21);
            this.rdButtonFeminino.Name = "rdButtonFeminino";
            this.rdButtonFeminino.Size = new System.Drawing.Size(81, 20);
            this.rdButtonFeminino.TabIndex = 16;
            this.rdButtonFeminino.TabStop = true;
            this.rdButtonFeminino.Text = "Feminino";
            this.rdButtonFeminino.UseVisualStyleBackColor = true;
            // 
            // gpBoxEstadoCivil
            // 
            this.gpBoxEstadoCivil.Controls.Add(this.rdButtonSolteiro);
            this.gpBoxEstadoCivil.Controls.Add(this.rdButtonCasado);
            this.gpBoxEstadoCivil.Location = new System.Drawing.Point(714, 187);
            this.gpBoxEstadoCivil.Name = "gpBoxEstadoCivil";
            this.gpBoxEstadoCivil.Size = new System.Drawing.Size(200, 100);
            this.gpBoxEstadoCivil.TabIndex = 18;
            this.gpBoxEstadoCivil.TabStop = false;
            this.gpBoxEstadoCivil.Text = "Estado Civil";
            // 
            // rdButtonSolteiro
            // 
            this.rdButtonSolteiro.AutoSize = true;
            this.rdButtonSolteiro.Location = new System.Drawing.Point(18, 59);
            this.rdButtonSolteiro.Name = "rdButtonSolteiro";
            this.rdButtonSolteiro.Size = new System.Drawing.Size(72, 20);
            this.rdButtonSolteiro.TabIndex = 17;
            this.rdButtonSolteiro.TabStop = true;
            this.rdButtonSolteiro.Text = "Solteiro";
            this.rdButtonSolteiro.UseVisualStyleBackColor = true;
            // 
            // rdButtonCasado
            // 
            this.rdButtonCasado.AutoSize = true;
            this.rdButtonCasado.Location = new System.Drawing.Point(18, 21);
            this.rdButtonCasado.Name = "rdButtonCasado";
            this.rdButtonCasado.Size = new System.Drawing.Size(74, 20);
            this.rdButtonCasado.TabIndex = 16;
            this.rdButtonCasado.TabStop = true;
            this.rdButtonCasado.Text = "Casado";
            this.rdButtonCasado.UseVisualStyleBackColor = true;
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoINSS.Location = new System.Drawing.Point(711, 348);
            this.lblDescontoINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(100, 16);
            this.lblDescontoINSS.TabIndex = 19;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoIRPF.Location = new System.Drawing.Point(711, 406);
            this.lblDescontoIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(99, 16);
            this.lblDescontoIRPF.TabIndex = 21;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // mskTxtBoxAliquotaINSS
            // 
            this.mskTxtBoxAliquotaINSS.Enabled = false;
            this.mskTxtBoxAliquotaINSS.Location = new System.Drawing.Point(250, 348);
            this.mskTxtBoxAliquotaINSS.Name = "mskTxtBoxAliquotaINSS";
            this.mskTxtBoxAliquotaINSS.Size = new System.Drawing.Size(100, 22);
            this.mskTxtBoxAliquotaINSS.TabIndex = 22;
            // 
            // mskTxtBoxDescontoIRPF
            // 
            this.mskTxtBoxDescontoIRPF.Enabled = false;
            this.mskTxtBoxDescontoIRPF.Location = new System.Drawing.Point(841, 400);
            this.mskTxtBoxDescontoIRPF.Name = "mskTxtBoxDescontoIRPF";
            this.mskTxtBoxDescontoIRPF.Size = new System.Drawing.Size(100, 22);
            this.mskTxtBoxDescontoIRPF.TabIndex = 23;
            // 
            // mskTxtBoxDescontoINSS
            // 
            this.mskTxtBoxDescontoINSS.Enabled = false;
            this.mskTxtBoxDescontoINSS.Location = new System.Drawing.Point(841, 348);
            this.mskTxtBoxDescontoINSS.Name = "mskTxtBoxDescontoINSS";
            this.mskTxtBoxDescontoINSS.Size = new System.Drawing.Size(100, 22);
            this.mskTxtBoxDescontoINSS.TabIndex = 24;
            // 
            // mskTxtBoxAliquotaIRPF
            // 
            this.mskTxtBoxAliquotaIRPF.Enabled = false;
            this.mskTxtBoxAliquotaIRPF.Location = new System.Drawing.Point(250, 394);
            this.mskTxtBoxAliquotaIRPF.Name = "mskTxtBoxAliquotaIRPF";
            this.mskTxtBoxAliquotaIRPF.Size = new System.Drawing.Size(100, 22);
            this.mskTxtBoxAliquotaIRPF.TabIndex = 25;
            // 
            // mskTxtBoxSalarioFamilia
            // 
            this.mskTxtBoxSalarioFamilia.Enabled = false;
            this.mskTxtBoxSalarioFamilia.Location = new System.Drawing.Point(250, 442);
            this.mskTxtBoxSalarioFamilia.Name = "mskTxtBoxSalarioFamilia";
            this.mskTxtBoxSalarioFamilia.Size = new System.Drawing.Size(100, 22);
            this.mskTxtBoxSalarioFamilia.TabIndex = 26;
            // 
            // mskTxtBoxSalarioLiquido
            // 
            this.mskTxtBoxSalarioLiquido.Enabled = false;
            this.mskTxtBoxSalarioLiquido.Location = new System.Drawing.Point(250, 485);
            this.mskTxtBoxSalarioLiquido.Name = "mskTxtBoxSalarioLiquido";
            this.mskTxtBoxSalarioLiquido.Size = new System.Drawing.Size(100, 22);
            this.mskTxtBoxSalarioLiquido.TabIndex = 27;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(58, 47);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(394, 29);
            this.lblTitulo.TabIndex = 28;
            this.lblTitulo.Text = "Calculadora de Salário Fatecana";
            // 
            // picBoxFatec
            // 
            this.picBoxFatec.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBoxFatec.Image = global::PSalario.Properties.Resources.Fatec_sorocaba;
            this.picBoxFatec.Location = new System.Drawing.Point(737, 491);
            this.picBoxFatec.Name = "picBoxFatec";
            this.picBoxFatec.Size = new System.Drawing.Size(258, 132);
            this.picBoxFatec.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxFatec.TabIndex = 29;
            this.picBoxFatec.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1076, 649);
            this.Controls.Add(this.picBoxFatec);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.mskTxtBoxSalarioLiquido);
            this.Controls.Add(this.mskTxtBoxSalarioFamilia);
            this.Controls.Add(this.mskTxtBoxAliquotaIRPF);
            this.Controls.Add(this.mskTxtBoxDescontoINSS);
            this.Controls.Add(this.mskTxtBoxDescontoIRPF);
            this.Controls.Add(this.mskTxtBoxAliquotaINSS);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.gpBoxEstadoCivil);
            this.Controls.Add(this.gpBoxSexo);
            this.Controls.Add(this.btnVerificarDesconto);
            this.Controls.Add(this.txtBoxSalarioBruto);
            this.Controls.Add(this.txtBoxNumeroFilhos);
            this.Controls.Add(this.txtBoxNomeFuncionario);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIRPF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.lblNumeroFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNomeFuncionario);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gpBoxSexo.ResumeLayout(false);
            this.gpBoxSexo.PerformLayout();
            this.gpBoxEstadoCivil.ResumeLayout(false);
            this.gpBoxEstadoCivil.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFatec)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFuncionario;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumeroFilhos;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIRPF;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.TextBox txtBoxNomeFuncionario;
        private System.Windows.Forms.TextBox txtBoxNumeroFilhos;
        private System.Windows.Forms.TextBox txtBoxSalarioBruto;
        private System.Windows.Forms.Button btnVerificarDesconto;
        private System.Windows.Forms.GroupBox gpBoxSexo;
        private System.Windows.Forms.RadioButton rdButtonFeminino;
        private System.Windows.Forms.RadioButton rdButtonMasculino;
        private System.Windows.Forms.GroupBox gpBoxEstadoCivil;
        private System.Windows.Forms.RadioButton rdButtonSolteiro;
        private System.Windows.Forms.RadioButton rdButtonCasado;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.MaskedTextBox mskTxtBoxAliquotaINSS;
        private System.Windows.Forms.MaskedTextBox mskTxtBoxDescontoIRPF;
        private System.Windows.Forms.MaskedTextBox mskTxtBoxDescontoINSS;
        private System.Windows.Forms.MaskedTextBox mskTxtBoxAliquotaIRPF;
        private System.Windows.Forms.MaskedTextBox mskTxtBoxSalarioFamilia;
        private System.Windows.Forms.MaskedTextBox mskTxtBoxSalarioLiquido;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.PictureBox picBoxFatec;
    }
}

