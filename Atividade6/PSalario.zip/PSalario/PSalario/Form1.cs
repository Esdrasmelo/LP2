﻿using System;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        private double salarioBruto = 0;
        private double salarioFamilia = 0;
        private int numeroFilhos = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void txtBoxAliquotaINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void CalculateAliquotaINSS()
        {

            if (this.salarioBruto < 800.47) mskTxtBoxAliquotaINSS.Text = "7.65%";
            else if (this.salarioBruto < 1050) mskTxtBoxAliquotaINSS.Text = "8.65%";
            else if (this.salarioBruto < 1400.77) mskTxtBoxAliquotaINSS.Text = "9.00%";
            else if (this.salarioBruto < 2801.56) mskTxtBoxAliquotaINSS.Text = "11.00%";
            else txtBoxSalarioBruto.Text = "Teto";

        }

        private void CalculateAliquotaIRPF()
        {

            if (this.salarioBruto < 1257.12) mskTxtBoxAliquotaIRPF.Text = "Isento";
            else if (this.salarioBruto < 2508.12) mskTxtBoxAliquotaIRPF.Text = "15.00%";
            else mskTxtBoxAliquotaINSS.Text = "27.5%";

        }

        private void CalculateSalarioFamilia()
        {
            if (this.salarioBruto < 435.52)
            {
                this.salarioFamilia = 22.33 * this.numeroFilhos;
                mskTxtBoxSalarioFamilia.Text = this.salarioFamilia.ToString("0.00");
            }
            else if (this.salarioBruto < 654.61)
            {
                this.salarioFamilia = 15.74 * this.numeroFilhos;
                mskTxtBoxSalarioFamilia.Text = this.salarioFamilia.ToString("0.00");
            }
            else mskTxtBoxSalarioFamilia.Text = "0,00";

        }

        private void CalculateDescontoINSS()
        {
            double calculateValue;
            if (this.salarioBruto < 800.47)
            {
                calculateValue = 0.0765 * this.salarioBruto;
                mskTxtBoxDescontoINSS.Text = calculateValue.ToString("0.00");
            }
            else if (this.salarioBruto < 1050)
            {
                calculateValue = 0.0865 * this.salarioBruto;
                mskTxtBoxDescontoINSS.Text = calculateValue.ToString("0.00");
            }
            else if (this.salarioBruto < 1400.77)
            {
                calculateValue = 0.09 * this.salarioBruto;
                mskTxtBoxDescontoINSS.Text = calculateValue.ToString("0.00");
            }
            else if (this.salarioBruto < 2801.56)
            {
                calculateValue = 0.11 * this.salarioBruto;
                mskTxtBoxDescontoINSS.Text = calculateValue.ToString("0.00");
            }
            else mskTxtBoxDescontoINSS.Text = "308.17";
        }

        private void CalculateDescontoIRPF()
        {
            double calculateValue;
            if (this.salarioBruto < 1257.12) mskTxtBoxDescontoIRPF.Text = "Isento";
            else if (this.salarioBruto < 2508.12)
            {
                calculateValue = 0.15 * this.salarioBruto;
                mskTxtBoxDescontoIRPF.Text = calculateValue.ToString("0.00");
            }
            else
            {
                calculateValue = 0.275 * this.salarioBruto;
                mskTxtBoxDescontoIRPF.Text = calculateValue.ToString("0.00");
            }
        }

        private void CalculateSalarioLiquido()
        {
            double netSalary;
            double inssDiscount = Convert.ToDouble(mskTxtBoxDescontoINSS.Text);
            double irpfDiscount = Convert.ToDouble(mskTxtBoxDescontoIRPF.Text);
            double familySalary = Convert.ToDouble(mskTxtBoxSalarioFamilia.Text);
            double valuesToBeDiscounted = inssDiscount + irpfDiscount;
            netSalary = (this.salarioBruto + familySalary) - valuesToBeDiscounted;
            mskTxtBoxSalarioLiquido.Text = netSalary.ToString("0.00");
        }

        private bool AreFieldsFilled()
        {
            bool isEmployeeNameEmpty = String.IsNullOrEmpty(txtBoxNomeFuncionario.Text);
            bool isEmployeeSalaryEmpty = String.IsNullOrEmpty(txtBoxSalarioBruto.Text);
            bool isNumberOfSonsEmpty = String.IsNullOrEmpty(txtBoxNumeroFilhos.Text);
            if (isEmployeeNameEmpty || isEmployeeSalaryEmpty || isNumberOfSonsEmpty) return false;
            return true;
        }

        private bool CanFieldsBeParsed()
        {
            bool tryParseNumberOfSonsField = int.TryParse(txtBoxNumeroFilhos.Text, out this.numeroFilhos);
            bool tryParseEmployeeSalary = Double.TryParse(txtBoxSalarioBruto.Text, out this.salarioBruto);
            if (tryParseEmployeeSalary && tryParseNumberOfSonsField) return true;
            return false;
        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            bool areFieldsFilled = this.AreFieldsFilled();
            bool canFieldsBeParsed = this.CanFieldsBeParsed();
            if (!areFieldsFilled || !canFieldsBeParsed)
            {
                MessageBox.Show("Por favor, preencha todos os campos fornecendo as informações necessárias e corretas.");
            }
            else
            {
                this.CalculateAliquotaINSS();
                this.CalculateAliquotaIRPF();
                this.CalculateSalarioFamilia();
                this.CalculateDescontoINSS();
                this.CalculateDescontoIRPF();
                this.CalculateSalarioLiquido();
            }
        }
    }
}
