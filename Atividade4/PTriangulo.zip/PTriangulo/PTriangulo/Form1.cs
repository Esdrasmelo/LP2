﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        private double value_A, value_B, value_C;
        private string triangleClassification;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private bool ValidateSide(double plusCalculationValue, double moduleValue, double sideValue)
        {
            if (sideValue > moduleValue && sideValue < plusCalculationValue) return true;
            return false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ClassifyTriangle()
        {
            bool areAllSidesDifferent = this.value_A != this.value_B && this.value_A != this.value_C && this.value_B != this.value_C;
            bool hasTwoEqualSides = this.value_A == this.value_B || this.value_A == this.value_C || this.value_B == this.value_C;
            bool areAllSidesEquals = this.value_A == this.value_B && this.value_B == this.value_C && this.value_A == this.value_C;
            if (areAllSidesEquals) this.triangleClassification = "Equiátero";
            else if (hasTwoEqualSides) this.triangleClassification = "Isósceles";
            else if (areAllSidesDifferent) this.triangleClassification = "Escaleno";
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            txtBoxFirstValue.Text = String.Empty;
            txtBoxSecondValue.Text = String.Empty;
            txtBoxThirdValue.Text = String.Empty;
        }

        private bool[] AreProvidedSidesValids()
        {
            bool[] hasValidSides = new bool[3];
            for (int index = 0; index < 3; index++)
            {
                double minusCalculation = 0;
                double plusCalculation = 0;
                double module = 0;
                if (index == 0)
                {
                    minusCalculation += this.value_B - this.value_C;
                    plusCalculation += this.value_B + this.value_C;
                    module += minusCalculation < 0 ? minusCalculation * (-1) : minusCalculation;
                    hasValidSides[index] = this.ValidateSide(plusCalculation, module, this.value_A);
                }
                else if (index == 1)
                {
                    minusCalculation += this.value_A - this.value_C;
                    plusCalculation += this.value_A + this.value_C;
                    module += minusCalculation < 0 ? minusCalculation * (-1) : minusCalculation;
                    hasValidSides[index] = this.ValidateSide(plusCalculation, module, this.value_B);
                } 
                else
                {
                    minusCalculation += this.value_A - this.value_B;
                    plusCalculation += this.value_A + this.value_B;
                    module += minusCalculation < 0 ? minusCalculation * (-1) : minusCalculation;
                    hasValidSides[index] = this.ValidateSide(plusCalculation, module, this.value_C);
                }
            }
            return hasValidSides;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            bool parseFirstValue = Double.TryParse(txtBoxFirstValue.Text, out this.value_A);
            bool parseSecondValue = Double.TryParse(txtBoxSecondValue.Text, out this.value_B);
            bool parseThirdValue = Double.TryParse(txtBoxThirdValue.Text, out this.value_C);
            bool wereNumbersParsed = parseFirstValue && parseSecondValue && parseThirdValue;
            if (wereNumbersParsed)
            {
                bool[] wereProvidedValidSides = this.AreProvidedSidesValids();
                if (wereProvidedValidSides.Contains(false)) MessageBox.Show("Os valores informados não podem formar um triângulo");
                else
                {
                    this.ClassifyTriangle();
                    MessageBox.Show("Os valores informados podem formar um Triângulo " + this.triangleClassification);
                }
            }
            else MessageBox.Show("Por favor, confira os números digitados e tente novamente!");

        }
    }
}
