﻿
namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblFirstValue = new System.Windows.Forms.Label();
            this.lblSecondValue = new System.Windows.Forms.Label();
            this.lblThirdValue = new System.Windows.Forms.Label();
            this.txtBoxFirstValue = new System.Windows.Forms.TextBox();
            this.txtBoxSecondValue = new System.Windows.Forms.TextBox();
            this.txtBoxThirdValue = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClean = new System.Windows.Forms.Button();
            this.picBoxFatec = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFatec)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFirstValue
            // 
            this.lblFirstValue.AutoSize = true;
            this.lblFirstValue.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstValue.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFirstValue.Location = new System.Drawing.Point(106, 104);
            this.lblFirstValue.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblFirstValue.Name = "lblFirstValue";
            this.lblFirstValue.Size = new System.Drawing.Size(71, 25);
            this.lblFirstValue.TabIndex = 0;
            this.lblFirstValue.Text = "Lado A";
            this.lblFirstValue.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblSecondValue
            // 
            this.lblSecondValue.AutoSize = true;
            this.lblSecondValue.BackColor = System.Drawing.Color.Transparent;
            this.lblSecondValue.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblSecondValue.Location = new System.Drawing.Point(106, 185);
            this.lblSecondValue.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblSecondValue.Name = "lblSecondValue";
            this.lblSecondValue.Size = new System.Drawing.Size(69, 25);
            this.lblSecondValue.TabIndex = 1;
            this.lblSecondValue.Text = "Lado B";
            this.lblSecondValue.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblThirdValue
            // 
            this.lblThirdValue.AutoSize = true;
            this.lblThirdValue.BackColor = System.Drawing.Color.Transparent;
            this.lblThirdValue.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblThirdValue.Location = new System.Drawing.Point(106, 269);
            this.lblThirdValue.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblThirdValue.Name = "lblThirdValue";
            this.lblThirdValue.Size = new System.Drawing.Size(70, 25);
            this.lblThirdValue.TabIndex = 2;
            this.lblThirdValue.Text = "Lado C";
            this.lblThirdValue.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtBoxFirstValue
            // 
            this.txtBoxFirstValue.Location = new System.Drawing.Point(216, 104);
            this.txtBoxFirstValue.Name = "txtBoxFirstValue";
            this.txtBoxFirstValue.Size = new System.Drawing.Size(187, 33);
            this.txtBoxFirstValue.TabIndex = 3;
            // 
            // txtBoxSecondValue
            // 
            this.txtBoxSecondValue.Location = new System.Drawing.Point(216, 185);
            this.txtBoxSecondValue.Name = "txtBoxSecondValue";
            this.txtBoxSecondValue.Size = new System.Drawing.Size(187, 33);
            this.txtBoxSecondValue.TabIndex = 4;
            // 
            // txtBoxThirdValue
            // 
            this.txtBoxThirdValue.Location = new System.Drawing.Point(216, 269);
            this.txtBoxThirdValue.Name = "txtBoxThirdValue";
            this.txtBoxThirdValue.Size = new System.Drawing.Size(187, 33);
            this.txtBoxThirdValue.TabIndex = 5;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(106, 354);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(107, 33);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Calcular";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(383, 354);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(107, 33);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Sair";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClean
            // 
            this.btnClean.Location = new System.Drawing.Point(244, 354);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(107, 33);
            this.btnClean.TabIndex = 8;
            this.btnClean.Text = "Limpar";
            this.btnClean.UseVisualStyleBackColor = true;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // picBoxFatec
            // 
            this.picBoxFatec.BackColor = System.Drawing.Color.Transparent;
            this.picBoxFatec.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picBoxFatec.Image = ((System.Drawing.Image)(resources.GetObject("picBoxFatec.Image")));
            this.picBoxFatec.Location = new System.Drawing.Point(553, 398);
            this.picBoxFatec.Name = "picBoxFatec";
            this.picBoxFatec.Size = new System.Drawing.Size(159, 68);
            this.picBoxFatec.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxFatec.TabIndex = 9;
            this.picBoxFatec.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.Location = new System.Drawing.Point(106, 33);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(285, 32);
            this.lblTitulo.TabIndex = 10;
            this.lblTitulo.Text = "Validador de Triângulos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(724, 478);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.picBoxFatec);
            this.Controls.Add(this.btnClean);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtBoxThirdValue);
            this.Controls.Add(this.txtBoxSecondValue);
            this.Controls.Add(this.txtBoxFirstValue);
            this.Controls.Add(this.lblThirdValue);
            this.Controls.Add(this.lblSecondValue);
            this.Controls.Add(this.lblFirstValue);
            this.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.SystemColors.Menu;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxFatec)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstValue;
        private System.Windows.Forms.Label lblSecondValue;
        private System.Windows.Forms.Label lblThirdValue;
        private System.Windows.Forms.TextBox txtBoxFirstValue;
        private System.Windows.Forms.TextBox txtBoxSecondValue;
        private System.Windows.Forms.TextBox txtBoxThirdValue;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.PictureBox picBoxFatec;
        private System.Windows.Forms.Label lblTitulo;
    }
}

