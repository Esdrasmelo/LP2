﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        private double weight = 0;
        private double height = 0;
        private double imc = 0;
        private string imcClassification = "";
        private int degreeObesity = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void SetImc() {
            double imcFormula = this.weight / (Math.Pow(this.height, 2));
            this.imc = Math.Round(imcFormula, 2);
        }

        private void SetImcClassification()
        {
            if (this.imc < 18.5) this.imcClassification = "Magreza";
            else if (this.imc >= 18.5 && this.imc <= 24.9) this.imcClassification = "Normal";
            else if (this.imc >= 25 && this.imc <= 29.9) this.imcClassification = "Sobrepeso";
            else if (this.imc >= 30 && this.imc <= 39.9) this.imcClassification = "Obesidade";
            else this.imcClassification = "Obesidade Grave";
        }

        private void SetDegreeObesity()
        {
            if (this.imcClassification == "Magreza" || this.imcClassification == "Normal") this.degreeObesity = 0;
            else if (this.imcClassification == "Sobrepeso") this.degreeObesity = 1;
            else if (this.imcClassification == "Obesidade") this.degreeObesity = 2;
            else this.degreeObesity = 3;
        }

        private bool AreFieldsFilled()
        {
            if (String.IsNullOrEmpty(txtAltura.Text) || String.IsNullOrEmpty(txtPeso.Text)) return false;
            return true;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!this.AreFieldsFilled())
            {
                MessageBox.Show("Por favor, preencha todos os campos");
            }

            if (Double.TryParse(txtPeso.Text, out this.weight) && Double.TryParse(txtAltura.Text, out this.height))
            {
                if (this.height >= 100) this.height = this.height / 100;
                this.SetImc();
                this.SetImcClassification();
                this.SetDegreeObesity();

                MessageBox.Show("Seu IMC é: " + this.imc + "\nClassificação: " + this.imcClassification + "\nObesidade (grau): " + this.degreeObesity);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = String.Empty;
            txtPeso.Text = String.Empty;
        }
    }
}
