﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double ConvertToDouble(string value) {
            return Convert.ToDouble(value);
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double radius, height;
            if (Double.TryParse(txtBoxRaio.Text, out radius) && Double.TryParse(txtBoxAltura.Text, out height))
            {
                if (height <= 0 || radius <= 0)
                {
                    MessageBox.Show("Por favor, digite números maiores que zero.");
                    if (height <= 0) txtBoxAltura.Focus();
                    else txtBoxRaio.Focus();
                }
                double volumeValue = Math.PI * Math.Pow(radius, 2) * height;
                MessageBox.Show("O valor do volume é de: " + volumeValue);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
