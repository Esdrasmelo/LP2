﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btniguais_Click(object sender, EventArgs e)
        {
            if (string.Compare(Txtpal1.Text, Txtpal2.Text, true) == 0)
                MessageBox.Show("São iguais");
            else
                MessageBox.Show("São diferentes!!!!");
        }

        private void btninserir1_Click(object sender, EventArgs e)
        {
            int meio = Txtpal2.Text.Length / 2;

            Txtpal2.Text = Txtpal2.Text.Substring(0, meio) +
                Txtpal1.Text + Txtpal2.Text.Substring(meio,
                Txtpal2.Text.Length - meio);

        }

        private void btninserir2_Click(object sender, EventArgs e)
        {
            int meio = Txtpal1.Text.Length / 2;
            Txtpal2.Text = Txtpal1.Text.Insert(meio, "**");
        }
    }
}
