﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtBox = new System.Windows.Forms.RichTextBox();
            this.btnQtdCaractNumericos = new System.Windows.Forms.Button();
            this.btnLocalizarPrimeiroCaracBranco = new System.Windows.Forms.Button();
            this.btnQtdCaracAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxtBox
            // 
            this.rchTxtBox.Location = new System.Drawing.Point(12, 12);
            this.rchTxtBox.Name = "rchTxtBox";
            this.rchTxtBox.Size = new System.Drawing.Size(406, 96);
            this.rchTxtBox.TabIndex = 0;
            this.rchTxtBox.Text = "";
            // 
            // btnQtdCaractNumericos
            // 
            this.btnQtdCaractNumericos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdCaractNumericos.Location = new System.Drawing.Point(12, 126);
            this.btnQtdCaractNumericos.Name = "btnQtdCaractNumericos";
            this.btnQtdCaractNumericos.Size = new System.Drawing.Size(405, 54);
            this.btnQtdCaractNumericos.TabIndex = 1;
            this.btnQtdCaractNumericos.Text = "Quantidade Caracteres Numéricos";
            this.btnQtdCaractNumericos.UseVisualStyleBackColor = true;
            this.btnQtdCaractNumericos.Click += new System.EventHandler(this.btnQtdCaractNumericos_Click);
            // 
            // btnLocalizarPrimeiroCaracBranco
            // 
            this.btnLocalizarPrimeiroCaracBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizarPrimeiroCaracBranco.Location = new System.Drawing.Point(13, 186);
            this.btnLocalizarPrimeiroCaracBranco.Name = "btnLocalizarPrimeiroCaracBranco";
            this.btnLocalizarPrimeiroCaracBranco.Size = new System.Drawing.Size(405, 54);
            this.btnLocalizarPrimeiroCaracBranco.TabIndex = 2;
            this.btnLocalizarPrimeiroCaracBranco.Text = "Localizar Primeiro Caracter Branco";
            this.btnLocalizarPrimeiroCaracBranco.UseVisualStyleBackColor = true;
            this.btnLocalizarPrimeiroCaracBranco.Click += new System.EventHandler(this.btnLocalizarPrimeiroCaracBranco_Click);
            // 
            // btnQtdCaracAlfabeticos
            // 
            this.btnQtdCaracAlfabeticos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdCaracAlfabeticos.Location = new System.Drawing.Point(13, 255);
            this.btnQtdCaracAlfabeticos.Name = "btnQtdCaracAlfabeticos";
            this.btnQtdCaracAlfabeticos.Size = new System.Drawing.Size(405, 54);
            this.btnQtdCaracAlfabeticos.TabIndex = 3;
            this.btnQtdCaracAlfabeticos.Text = "Qtd Caracteres Alfabéticos";
            this.btnQtdCaracAlfabeticos.UseVisualStyleBackColor = true;
            this.btnQtdCaracAlfabeticos.Click += new System.EventHandler(this.btnQtdCaracAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(430, 331);
            this.Controls.Add(this.btnQtdCaracAlfabeticos);
            this.Controls.Add(this.btnLocalizarPrimeiroCaracBranco);
            this.Controls.Add(this.btnQtdCaractNumericos);
            this.Controls.Add(this.rchTxtBox);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtBox;
        private System.Windows.Forms.Button btnQtdCaractNumericos;
        private System.Windows.Forms.Button btnLocalizarPrimeiroCaracBranco;
        private System.Windows.Forms.Button btnQtdCaracAlfabeticos;
    }
}