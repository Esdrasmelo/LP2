﻿using System;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdCaractNumericos_Click(object sender, EventArgs e)
        {
            int qtdNumeros = 0;
            for (int contador = 0; contador < rchTxtBox.Text.Length; contador++)
            {

                if (Char.IsNumber(rchTxtBox.Text, contador))
                    qtdNumeros++;
            }
            MessageBox.Show("Contém " + qtdNumeros + " Números!");
        }

        private void btnLocalizarPrimeiroCaracBranco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicao = 0;
            while (contador < rchTxtBox.Text.Length)
            {
                if (Char.IsWhiteSpace(rchTxtBox.Text[contador])) posicao = rchTxtBox.Text.IndexOf(rchTxtBox.Text[contador]);
                contador++;
            }
            if (posicao < 0) MessageBox.Show("Não há espaços em branco");
            else MessageBox.Show("A posição do primeiro espaço em branco é: " + posicao);
        }

        private void btnQtdCaracAlfabeticos_Click(object sender, EventArgs e)
        {
            int qtdLetras = 0;
            foreach (char caracter in rchTxtBox.Text)
            {
                if (Char.IsLetter(caracter)) qtdLetras++;
            }
            MessageBox.Show("Há " + qtdLetras + " letras!");
        }
    }
}
