﻿using System;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[2];

            if (int.TryParse(txtBoxNumero1.Text, out numeros[0]) && int.TryParse(txtBoxNumero2.Text, out numeros[1]))
            {
                var random = new Random();
                int indice = random.Next(numeros.Length);
                int numeroSorteado = numeros[indice];

                MessageBox.Show("O número sorteado foi: " + numeroSorteado);
            }
        }
    }
}
