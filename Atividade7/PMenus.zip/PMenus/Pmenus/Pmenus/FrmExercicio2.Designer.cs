﻿namespace Pmenus
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpal1 = new System.Windows.Forms.Label();
            this.lblpal2 = new System.Windows.Forms.Label();
            this.Txtpal1 = new System.Windows.Forms.TextBox();
            this.Txtpal2 = new System.Windows.Forms.TextBox();
            this.btniguais = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpal1
            // 
            this.lblpal1.AutoSize = true;
            this.lblpal1.BackColor = System.Drawing.Color.Transparent;
            this.lblpal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpal1.Location = new System.Drawing.Point(21, 64);
            this.lblpal1.Name = "lblpal1";
            this.lblpal1.Size = new System.Drawing.Size(74, 20);
            this.lblpal1.TabIndex = 0;
            this.lblpal1.Text = "Palavra 1";
            // 
            // lblpal2
            // 
            this.lblpal2.AutoSize = true;
            this.lblpal2.BackColor = System.Drawing.Color.Transparent;
            this.lblpal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpal2.Location = new System.Drawing.Point(21, 110);
            this.lblpal2.Name = "lblpal2";
            this.lblpal2.Size = new System.Drawing.Size(74, 20);
            this.lblpal2.TabIndex = 1;
            this.lblpal2.Text = "Palavra 2";
            // 
            // Txtpal1
            // 
            this.Txtpal1.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtpal1.Location = new System.Drawing.Point(141, 64);
            this.Txtpal1.Name = "Txtpal1";
            this.Txtpal1.Size = new System.Drawing.Size(114, 23);
            this.Txtpal1.TabIndex = 2;
            // 
            // Txtpal2
            // 
            this.Txtpal2.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txtpal2.Location = new System.Drawing.Point(141, 107);
            this.Txtpal2.Name = "Txtpal2";
            this.Txtpal2.Size = new System.Drawing.Size(114, 23);
            this.Txtpal2.TabIndex = 3;
            // 
            // btniguais
            // 
            this.btniguais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btniguais.Location = new System.Drawing.Point(25, 180);
            this.btniguais.Name = "btniguais";
            this.btniguais.Size = new System.Drawing.Size(120, 58);
            this.btniguais.TabIndex = 4;
            this.btniguais.Text = "Testar iguais";
            this.btniguais.UseVisualStyleBackColor = true;
            this.btniguais.Click += new System.EventHandler(this.btniguais_Click);
            // 
            // btninserir2
            // 
            this.btninserir2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninserir2.Location = new System.Drawing.Point(303, 180);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(120, 58);
            this.btninserir2.TabIndex = 5;
            this.btninserir2.Text = "Inserir Asteriscos no Texto 1";
            this.btninserir2.UseVisualStyleBackColor = true;
            this.btninserir2.Click += new System.EventHandler(this.btninserir2_Click);
            // 
            // btninserir1
            // 
            this.btninserir1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninserir1.Location = new System.Drawing.Point(166, 180);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(120, 58);
            this.btninserir1.TabIndex = 6;
            this.btninserir1.Text = " Inserir Texto 1 no Texto 2";
            this.btninserir1.UseVisualStyleBackColor = true;
            this.btninserir1.Click += new System.EventHandler(this.btninserir1_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(460, 304);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btniguais);
            this.Controls.Add(this.Txtpal2);
            this.Controls.Add(this.Txtpal1);
            this.Controls.Add(this.lblpal2);
            this.Controls.Add(this.lblpal1);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpal1;
        private System.Windows.Forms.Label lblpal2;
        private System.Windows.Forms.TextBox Txtpal1;
        private System.Windows.Forms.TextBox Txtpal2;
        private System.Windows.Forms.Button btniguais;
        private System.Windows.Forms.Button btninserir2;
        private System.Windows.Forms.Button btninserir1;
    }
}