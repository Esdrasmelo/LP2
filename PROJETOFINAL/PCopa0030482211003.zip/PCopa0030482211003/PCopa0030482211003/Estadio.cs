﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace PCopa0030482211003
{
    class Estadio
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter dataAdapterEstadio;

            DataTable dataTableEstadio = new DataTable();

            try
            {
                dataAdapterEstadio = new SqlDataAdapter("SELECT * FROM ESTADIO ORDER BY NOME", frmPrincipal.conexaoSql);
                dataAdapterEstadio.Fill(dataTableEstadio); // preencha o DataTable com os dados que foram pegos no DataAdapter
                dataAdapterEstadio.FillSchema(dataTableEstadio, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }

            return dataTableEstadio;
        }
    }
}
