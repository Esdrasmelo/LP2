﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PCopa0030482211003
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexaoSql;
        
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexaoSql = new SqlConnection("Data Source=Apolo;Initial Catalog=LP2;User ID=BD2211003;Password=whitz_dev_sqlserver22!!");
                conexaoSql.Open();
            } 
            catch (SqlException ex) 
            { 
                MessageBox.Show("Erro de banco de dados =/" + ex.Message); 
            } 
            catch (Exception ex) 
            { 
                MessageBox.Show("Outros Erros =/" + ex.Message); 
            } 
        }
    }
}
