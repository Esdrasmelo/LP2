﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace PCopa0030482211003
{
    class Jogo
    {
        public int Id { get; set; }

        public int EstadioId { get; set; }

        public int PaisId1 { get; set; }

        public int PaisId2 { get; set; }

        public DateTime Datahora { get; set; }

        public char Grupo { get; set; }

        public string Observacao { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter dataAdapterjogo;

            DataTable dataTablejogo = new DataTable();

            try
            {
                dataAdapterjogo = new SqlDataAdapter("SELECT * FROM JOGO", frmPrincipal.conexaoSql);
                dataAdapterjogo.Fill(dataTablejogo); // preencha o DataTable com os dados que foram pegos no DataAdapter
                dataAdapterjogo.FillSchema(dataTablejogo, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }

            return dataTablejogo;
        }
        public int Excluir()
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM JOGO WHERE ID=@id", frmPrincipal.conexaoSql);

                mycommand.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
                mycommand.Parameters["@id"].Value = Id;

                nReg = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return nReg;
        }
        public int Salvar() 
        { 
            int retorno = 0; 

            try
            { 
                 SqlCommand mycommand; 

                 int nReg; 

                 mycommand = new SqlCommand("INSERT INTO JOGO VALUES (@pais1, @pais2, @estadio, @datahora, @observacao)", frmPrincipal.conexaoSql); 
                
                 mycommand.Parameters.Add(new SqlParameter("@pais1", SqlDbType.Int)); 

                 mycommand.Parameters.Add(new SqlParameter("@pais2", SqlDbType.Int));

                 mycommand.Parameters.Add(new SqlParameter("@estadio", SqlDbType.Int));

                 mycommand.Parameters.Add(new SqlParameter("@datahora", SqlDbType.Date));

                 mycommand.Parameters.Add(new SqlParameter("@observacao", SqlDbType.VarChar));

                 mycommand.Parameters["@pais1"].Value = PaisId1;

                 mycommand.Parameters["@pais2"].Value = PaisId2;

                 mycommand.Parameters["@estadio"].Value = EstadioId;

                 mycommand.Parameters["@datahora"].Value = Datahora;

                 mycommand.Parameters["@observacao"].Value = Observacao;

                 nReg = mycommand.ExecuteNonQuery();
 
                 if (nReg > 0) 
                 { 
                    retorno = nReg; 
                 } 
            } 
            catch (Exception ex) 
            { 
                throw ex; 
            } 
            return retorno; 
        }
        public int Alterar() //Paramos no alterar
        { 
            int retorno = 0; 

            try
        { 
            SqlCommand mycommand; 
            int nReg = 0; 
            mycommand = new SqlCommand("UPDATE TBCIDADE SET nome_cidade = @nome_cidade ,uf_cidade = @uf_cidade WHERE id_cidade = @id_cidade", 
frmPrincipal.conexao); 
            mycommand.Parameters.Add(new SqlParameter("@id_cidade", SqlDbType.Int)); 
            mycommand.Parameters.Add(new SqlParameter("@nome_cidade", SqlDbType.VarChar)); 
            mycommand.Parameters.Add(new SqlParameter("@uf_cidade", SqlDbType.Char)); 
            mycommand.Parameters["@id_cidade"].Value = idcidade; 
            mycommand.Parameters["@nome_cidade"].Value = nomecidade; 

            mycommand.Parameters["@uf_cidade"].Value = ufcidade; nReg = mycommand.ExecuteNonQuery(); 
            if (nReg > 0) 
            { 
                retorno = nReg; 
            } 
        } 
        catch (Exception ex) 
        { 
            throw ex; 
        } 
        return retorno; 
     } 
}
