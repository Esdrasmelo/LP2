﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        private double firstNumber, secondNumber, result;

        public Form1()
        {
            InitializeComponent();
        }

        private void ResultMessage() {
            txtResultado.Text = Convert.ToString(this.result);
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {

            if (Double.TryParse(txtNumero1.Text, out this.firstNumber) && Double.TryParse(txtNumero2.Text, out this.secondNumber))
            {
                this.result = firstNumber + secondNumber;
                this.ResultMessage();
            }   
        }
    }
}
