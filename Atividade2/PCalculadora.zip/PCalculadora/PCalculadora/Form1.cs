﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        private double firstNumber, secondNumber, result;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            if (this.canInputNumbersBeParsed())
            {
                this.result = this.firstNumber - this.secondNumber;
                this.ResultMessage();
            }
        }

        private bool canInputNumbersBeParsed()
        {
            bool canFirstNumberBeParsed = Double.TryParse(txtNumero1.Text, out this.firstNumber);
            bool canSecondNumberBeParsed = Double.TryParse(txtNumero2.Text, out this.secondNumber);
            if (canFirstNumberBeParsed && canSecondNumberBeParsed) return true;
            return false;
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (this.canInputNumbersBeParsed())
            {
                if (this.secondNumber == 0)
                {
                    MessageBox.Show("Por favor, digite um número diferente de zero.");
                    txtNumero2.Focus();
                } else
                {
                    this.result = this.firstNumber / this.secondNumber;
                    this.ResultMessage();
                }                
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            if (this.canInputNumbersBeParsed())
            {
                this.result = this.firstNumber * this.secondNumber;
                this.ResultMessage();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = string.Empty;
            txtNumero2.Text = string.Empty;
            txtResultado.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNumero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResultMessage() {
            txtResultado.Text = Convert.ToString(this.result);
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            if (this.canInputNumbersBeParsed())
            {
                this.result = this.firstNumber + this.secondNumber;
                this.ResultMessage();
            }   
        }
    }
}
